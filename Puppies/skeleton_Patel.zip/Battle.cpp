// CS1300 Fall 2019
// Author: Ishika Patel
// Recitation: 104 - Anuj P
// Project Puppies

// BATTLE CLASS IS IN CHARGE OF THE LOVE BATTLES AND ADJUSING CUDDLE POINTS
// READ IN FROM FILES HERE TO FILL AN ARRAY OF PUPPY OBJECTS

#include <iostream>
#include <string>
#include <math.h>

/*
         //capacity of puppy array
        const int sizePuppy = 100;
        //array of puppy objects
        Puppy friends[100];
        // the fighter's cuddle points read in from the file
        int friendCuddlePoints;
        // read in from files to pick a random dog to love battle, index of this puppy
        int randomFriend;
        // items also loaded into the puppy array
        string friendName;
        int friendAge;
        // write into file the puppyBattle Results
        string PuppyBattleResults;
        // this is the number of 
        int cuddlePointsAtStake;
    */
        
    int Battle:: getFriendPoints(){
         // read in from a file int the puppy object
         // fill the puppy object (CONSIDER FILLING A DIFFERENT FUNCTION?)
    }
    // set points from the puppy object array
    void Battle:: setFriendPoints(int points){
        points = friendCuddlePoints;
    }
    int Battle:: getUserPoints(){
        return // puppy stats from the puppy user object, call on puppy class here
    }
    int Battle:: getRandomFriend(){
        // chooes a number 1-100 that the user randomly fights
        // this gives an index value of where to look in the puppy object 
    }
    void Battle:: setRandomFriend(int friendIndex_){
        friendIndex_ = randomFriend;
    }
    void Battle:: printBattleMenu(){
        /* "You will be battling (INSERT PUPPY NAME), they love (FAVE TOY, AGE, COLOR, BREED) WHO WILL WIN AND LOVE MORE??"
    }