#ifndef PUPPY_H
#define PUPPY_H
using namespace std;

class Puppy() {
    private:
        //name of puppy, user will give this in the game
        string puppyName;
        // breed of puppy, for the user use a menu to pick a breed
        string puppyBreed;
        //charateristic, you start off with 10 * the age points
        int puppyAge;
        // used as HP points to determine status
        int cuddlePoints;
    public:
        // default constructor, sets name & breed to empty, age to 1, cuddlePoints to 0 
        Puppy();
        //parametrized constructor        
        Puppy(string name, string breed, int age, int cuddlePoints_);
        void printPuppyMenu();
        void setPuppyName()
        string getPuppyName(string name);
        void setPuppyBreed();
        string getPuppyBreed();
        void setPuppyAge();
        int getPuppyAge();
        //initial cuddle points are based off of age given age * 10
        setCuddlePoints();
        getCuddlePoints();

};