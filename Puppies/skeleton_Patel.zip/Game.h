#ifndef GAME_H
#define GAME_H
using namespace std;

class Game() {
    private:
        //array of Puppy Objects
        const int sizePuppies = 100;
        Puppy puppies[100];
        //array of Toy Objects
        cosnt int sizeToys = 10;
        Toy toys[10];
        int toyIndex[][]
        
    public:
        bool checkToy();
        //calls on the toy class to get the chosen toy
        int getToyIndex();
        void setToyIndex();
        // calls on the triva question
        //random number generator for difficulty?
        string printToyTrivia();
        
};