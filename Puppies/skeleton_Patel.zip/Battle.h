#ifndef BATTLE_H
#define BATTLE_H
using namespace std;

class Battle() {
    private:
        //capacity of puppy array
        const int sizePuppy = 100;
        //array of puppy objects
        Puppy friends[100];
        // the fighter's cuddle points read in from the file
        int friendCuddlePoints;
        // read in from files to pick a random dog to love battle, index of this puppy
        int randomFriend;
        // items also loaded into the puppy array
        string friendName;
        int friendAge;
        // write into file the puppyBattle Results
        string PuppyBattleResults;
        // this is the number of 
        int cuddlePointsAtStake;
        
    public:
    // read in from a file int the puppy object
    int getFriendPoints();
    // set points from the puppy object array
    void setFriendPoints(int points);
    int getUserPoints();
    // choes a number 1-50 that the user randomly fights
    int getRandomFriend();
    void setRandomFriend(int friendIndex_);
    void printBattleMenu();
};