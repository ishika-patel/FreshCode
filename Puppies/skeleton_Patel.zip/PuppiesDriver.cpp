/*
10 by 10 field, 10 toys located around the point of the game is to find all 10 toys
end game by : finding all 10 toys, losing all cuddle points, quitting
*/

#include <iostream> 
#include <fstream>
#include <string.h>
#include <cctype>
#include <math.h>
using namespace std;

void primaryGameMenu() {
    /* 
    1. Move
    2. See Your Battle Stats
    3. Toy Search
    4. See Your Map Location
    5. More About Me!
    6. QUIT
    */
}

int main() {
    
Game myGame;

    string userInput; 
    bool check = true;

while(check == true){
    primaryGameMenu();
    getline(cin,userInput);
    if (stoi(userInput) == 1) {
    /* ask for user input, based on user answer move the position on the 2D array in the row or columns
    check bool value to see if there is a toy
    if there is a toy queue a trivia question
    if there isnt there must be a love battle
    */
    }
    if (stoi(userInput) == 2) {
    /* when the battles are lost or won, the battle stats are written into a file of what puppy was fought and if won
    us this to show cuddle points gained or lost as well */
    }
    
    if (stoi(userInput) == 3) {
    /* see how many toys have been found and see which toys have not been found, located info in the toy class */
    }
    if (stoi(userInput) == 4) {
    /* call on the map class, this is in the toy object, user can see where they are and where they have been, this allows them to track a path */
    }
    if (stoi(userInput) == 5) {
    /* bump up your puppies status via cuddle points, roll random dice (random number generator) and see if you lose gain or lose all your cuddle points */
    }
    if (stoi(userInput) == 6) {
            cout << "Thank you" << user << " for playing!" << endl;
            cout << "Here are your stats: " endl;
            // display stats function, call on puppy class (shows us users stats)
                //age, cuddle points, toys found
    }
    else {
        cout << "Invalid Input Try Again" << endl;
    }

    
    cout << endl;
}
}