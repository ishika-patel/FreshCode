// CS1300 Fall 2019
// Author: Ishika Patel
// Recitation: 104 - Anuj P
// Project Puppies

#include <iostream>
#include <string>
#include <math.h>
/*
    //array of Puppy Objects
        const int sizePuppies = 100;
        Puppy puppies[100];
        //array of Toy Objects
        cosnt int sizeToys = 10;
        Toy toys[10];
        toy index[][], numbers stored in indexes where toys will be cued
*/
        
        bool checkToy(){
            check location with toy index number 
            for (row)
                for (col) {
                    if user input == both then make check toy true
                }
            if (toy is false) {
                no toy;
                must love battle;
            }
            else{
                cue trivia;
                if (trivia won){
                    toy acquired ++:
                }
                else {
                    no toy won;
                }
            }
        }
        //calls on the toy class to get the chosen toy
        int getToyIndex(){
            random numbers set where the toys are, there are 10 toys hidden
            // this stores the toys indexes in a 2D array??
        }
        void setToyIndex(index[][]){
            stored indexes are set here using rnadom number gernator from 0 to 9 (10 by 10 array map)
        }
        // calls on the triva question
        //random number generator for difficulty?
        string printToyTrivia(){
            cout<< question <<;
            check answer;
            if correct (add toy)
            else (lose 50 points??)
        }