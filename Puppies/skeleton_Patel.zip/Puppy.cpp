// CS1300 Fall 2019
// Author: Ishika Patel
// Recitation: 104 - Anuj P
// Project Puppies

#include <iostream>
#include <string>
#include <math.h>
/*
        //name of puppy, user will give this in the game
        string puppyName;
        // breed of puppy, for the user use a menu to pick a breed
        string puppyBreed;
        //charateristic, you start off with 10 * the age points
        int puppyAge;
        // used as HP points to determine status
        int cuddlePoints;
*/

        // default constructor, sets name & breed to empty, age to 1, cuddlePoints to 0 
       Puppy:: Puppy(){
            puppyAge = 1;
            puppyBreed = "";
            puppyName = "";
        }
        //parametrized constructor        
        Puppy:: Puppy(string name, string breed, int age, int cuddlePoints_){
            name = puppyName;
            breed = puppyBreed;
            age = puppyAge;
            cuddlePoints_ = cuddlePoints;
        }
        
        void Puppy:: printPuppyMenu(){
            /* Menu of the 4-5 puppies that the user can choose from */
        }
        
        void Puppy:: setPuppyName(string name){
            name = puppyName;
        }
        string Puppy:: getPuppyName(){
            return puppyName;
        }
        void Puppy:: setPuppyBreed(string breed){
            breed = puppyBreed;
        }
        string Puppy:: getPuppyBreed(){
            return puppyBreed;
        }
        void Puppy:: setPuppyAge(int age){
            age = puppyAge;
        }
        int Puppy:: getPuppyAge(){
            return puppyAge;
        }
        //initial cuddle points are based off of age given age * 10
        void setCuddlePoints(int cuddlePoints_){
            cuddlePoints_ = puppyAge * 10;
            cuddlePoints_ = cuddlePoints;
        }
        int getCuddlePoints(){
            return cuddlePoints;
        }