#ifndef TOY_H
#define TOY_H
using namespace std;

// this is the map class

class Toy() {
    private:
        stringtrivia[]
        // reading in from files
        string question;
        string answer;
        //true if there is a toy
        bool toyLocation;
        // 2D array as a map, need to sort toys into map locations
        // ASK TA: HOW DO YOU SORT POKEMON INTO DIFFERNT LOCATIONS???
        int map[][];
        string toyName;
        int triviaDifficulty;
        int userRow;
        int userCol;
        
    public:
        Toy();
        Toy(string toyName, bool toyLocation, string question, string answer);
        int getDifficulty();
        void printMap();
        // this will be the users location
        int getMapLocation();
        void setMapLocation();
        int split(string line, char delimiter, string array[], int arraySize);
        void setToyName();
        string getToyName();
        void getQuestion();
        string setQuestion();
        void getAnswer();
        string setAnswer();
};