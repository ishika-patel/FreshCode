/*
10 by 10 field, 10 toys located around the point of the game is to find all 10 toys
end game by : finding all 10 toys, losing all cuddle points, quitting
*/

#include <iostream> 
#include <fstream>
#include <string.h>
#include <cctype>
#include <math.h>
using namespace std;

int main() {
    Game myGame;
    myGame.mainGame();
}