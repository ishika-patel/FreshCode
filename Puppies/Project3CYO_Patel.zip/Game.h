#ifndef GAME_H
#define GAME_H
using namespace std;

    
    /* 1. Game Directions
    2. Love Battle Directions
    3. Move
    4. Learn More About Your Puppy
    5. See Your Puppy Stats
    6. QUIT
    */

class Game {
    private:
        //array of Puppy Objects
        const int sizePuppies = 50;
        Puppy puppyFriends[50];
        //array of Toy Objects
        cosnt int sizeToys = 25;
        Toy toys[25];
        string printMap[][];
        //obstacles
        //
    public:
        //calls on the toy class to get the chosen toy
        bool checkToy();
//triva function
        void toyChest();
        int random1to100(); //a probability value
        int random0to49(); //value of a variable
        int random0to24();//value of a variable
        void primaryGameMenu();
        void secondaryDirectionsMenu();
        void mainGame();
};