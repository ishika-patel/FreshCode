// CS1300 Fall 2019
// Author: Ishika Patel
// Recitation: 104 - Anuj P
// Project Puppies

#include <iostream>
#include <string>
#include <math.h>
#include <fstream>
#include <cctype>
#include "Map.h"
using namespace std;

void Map:: loadMap(string fileName){
    string testArray[10];
    int rows = 0;
    int columns = 0;
    string line; 
    ifstream file; //says there is a file we will access and we are taking data from it
    file.open(fileName); //opens the file
    
    if (!(file.is_open())) {
        cout << "ERROR LOADING MAP" << endl;
    }
    
    else if (file.is_open()) { //checks to see if file is open
        while (getline(file,line)) { //reads line by 
            if (line != "") { //checks to make sure array is not full nor is the line empty
                split(line, ',', testArray, 10);  // used to separate the rows
            
                for(int i = 0; i < 10; i++){   // checks to see how many columns are occupied so that the program doesnt overload when "copying" the columns
                    if(testArray[i] != "") { 
                       mapArray[rows][i] = testArray[i];
                       columns++;
                    }
                }
           }
           rows++;
        }
    }
}

void Map:: displayMap(){
    for(int row = 0; row < 10; row++){
        for(int col = 0; col < 10; col++){
            cout << mapArray[row][col] << " ";
        }
    }
}

void Map:: specialTiles(){
/*
ask for 2 numbers create 2D array based on this, print out 2D array at end
        cin >> num 1
        cin >> num 2
        if row 5 cue special tiles
        
special tiles:
cout << "youve encountered a stick" << endl;
menu: what do you want to do with the stick?
    a.throw it (add to toy count)
    b.drop it (drop 10 cuddle points, how dare you give up a toy)
*/
}


