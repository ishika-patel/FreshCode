// CS1300 Fall 2019
// Author: Ishika Patel
// Recitation: 104 - Anuj P
// Project Puppies

#include <iostream> 
#include <fstream>
#include <string.h>
#include <cctype>
#include <math.h>
using namespace std;
 
// FUNCTION THAT INPUTS THE PUPPY NAMES INTO OBJECT

void Game:: secondaryDirectionsMenu() {
    cout << "WELCOME TO PUPPY LAND! What do you want to learn about?" << endl;
    cout << "Select a numerical option:" << endl;
    cout << "======Secondary Menu=====" << endl;
    cout << "1. General Game Directions" << endl;
    cout << "2. Love Battle Directions" << endl;
}

void Game:: primaryGameMenu() {
    cout << "WELCOME TO PUPPY LAND!" << endl;
    cout << "Select a numerical option:" << endl;
    cout << "======Main Menu=====" << endl;
    cout << "1. Get Directions" << endl; //simply print out
    cout << "2.  Learn More About Your Puppy" << endl; //puppy class, print out myPuppy object
    cout << "3. See Your Toy Trunk" << endl; //if numToys 0 else seen from the written file
    cout << "4. Rest" << endl; //lose one toy count but win 100 c points
    cout << "5. MOVE" << endl; //game class?? ask for 2 numbers create 2D array based on this, print out 2D array at end
    cout << "6. QUIT" << endl;
    */
}

void Game:: mainGame() {
    // prints map and stats every time NEEDS TO OCCUR...
    Puppy myPuppy;
    int numToysCollected = 0;
    bool charChoice = true;
    const int sizePuppy = 50;
    //array of puppy objects
    Puppy friends[50];
    const int sizeToy = 25;
    Toy toys[25];
    
    while (charChoice == true) {
        string userPup;
        cout<< "WELCOME TO YOUR PUPPY ADVETURE!" << endl;
        cout<< "CHOOSE YOUR LOVER!!!!" << endl;
        cout << "Please enter the number of the puppy you wish to adventure with."
        cout << "1. Tubby" << endl;
        cout << "2. Candice" << endl;
        cout << "3. Karen" << endl;
        cout << "4. Tofu" << endl;
        
        getline(cin,userPup);
        if (stoi(userPup) == 1){
            cout << "Congrats, you are Tubby the Puppy!" << endl;
            myPuppy.setPuppyName("Tubby");
            myPuppy.setPuppyBreed("German Shepherd");
            myPuppy.setPuppyAge("3");
            myPuppy.setPuppyGender("Male");
            myPuppy.setPuppyToy("Chuck It!");
            myPuppy.setPuppyColor("Green");
            myPuppy.setPuppyCPoints(1000);
            
            charChoice = false;
        }
        if (stoi(userPup) == 2){
            cout << "Congrats, you are Candice the Puppy!" << endl;
            myPuppy.setPuppyName("Candice");
            myPuppy.setPuppyBreed("Poodle");
            myPuppy.setPuppyAge("4");
            myPuppy.setPuppyGender("Female");
            myPuppy.setPuppyToy("Rope");
            myPuppy.setPuppyColor("Yellow");
            myPuppy.setPuppyCPoints(1000);
            charChoice = false;
        }
        if (stoi(userPup) == 3){
            cout << "Congrats, you are Karen the Puppy!" << endl;
            myPuppy.setPuppyName("Karen");
            myPuppy.setPuppyBreed("Corgie");
            myPuppy.setPuppyAge("4");
            myPuppy.setPuppyGender("Female");
            myPuppy.setPuppyToy("Ball");
            myPuppy.setPuppyColor("Pink");
            myPuppy.setPuppyCPoints(1000);
            
            charChoice = false;
        }
        if (stoi(userPup) == 4){
            cout << "Congrats, you are Tofu the Puppy!" << endl;
            myPuppy.setPuppyName("Tofu");
            myPuppy.setPuppyBreed("Samoyed");
            myPuppy.setPuppyAge("5");
            myPuppy.setPuppyGender("Male");
            myPuppy.setPuppyToy("Stuffed Otter");
            myPuppy.setPuppyColor("Blue");
            myPuppy.setPuppyCPoints(1000);
            charChoice = false;
        }
        else {
            cout << "This input is invalid. Try Again." << endl;
        }
    }

    string userInput; 
    bool check = true;
    
    while(check == true){
        primaryGameMenu();
        getline(cin,userInput);
        
        if (stoi(userInput) == 1) {
            /* 
            1. Directions
            secondaryDirectionsMenu();
            string directionsChoice;
            getline(cin,directionsChoice);
            
            if(stoi(directionsChoice) == 1){
                
            }
            if(stoi(directionsChoice) == 2) {
                
            }
            else {
              cout << "Woof! This is an Invalid Input" << endl;
            }
            */
        }
        
        if (stoi(userInput) == 2) {
        /* 2.Learn More About Your Puppy
        a void function called that prints all the puppies stats like a story
        */
        }
        
        if (stoi(userInput) == 3) {
        /*  1. See Your Toy Trunk
        see how many number of toys have been found 
        if (num toys 0) :
        cout << "You are toy-less" << endl;
        
        else {
        cout file written into
        }
        */
        
        }
        if (stoi(userInput) == 4) {
        /* 4. Rest
        if toys num >0{
            
        }
        lose one toy count but win 100 c points
        toy count -1
        myPuppy.setCPoints(myPuppy.getCPoints +100)
        
        }
        else {
            you cannot rest
        }
        */
        }
        if (stoi(userInput) == 5) {
        /* 5. MOVE
        ask for 2 numbers create 2D array based on this, print out 2D array at end
        cin >> num 1
        cin >> num 2
        if row 5 cue special tiles
        function that creates map OUTSIDE LOOP (double 4 to simple part)
        function that changed the map now (double 4 loop to change specific part, mapchange(int row, int col) when getting to row and col you change to a *)
        function that simply prints map (double 4 loop)
        
        checktoy -> rand -> if toy found you do that else -> menu, love battle or lose 5 c points
            - check toy
            - random mum gernator
            - menu
            - battle function

        void trivia{
            
            cout << "YOUR SNOOT HAS SNIFFED A TOY!"<< endl;
            cout << "Answer correctly and win the toy:" << endl;
            cout << endl;
            int triviaNumber = random 0 to 24 ();
            cout << toys[triviaNumber].getQuestion()<< endl;
            cout << toys[triviaNumber].getChoice() << endl;
            cin >> user input; USE GET LINE....
            if userInput == stoi(toys[triviaNumber].getAnswer()){
                WRITE INTO FILE;
                NUM TOYS ++ (dont mess this up bc its complicated)
            }
            else {
                cout << "Mom yelled at you for digging :(" << endl;
                cout << "No toy for you and a loss of cuddle points." << endl;
                myPuppy.setPuppyCPoints(myPuppy.getPuppyCPoints() - 50);
            }
        }
  
        bool checkToy(){
       int rando1to100 =  call on random number fuction
        if (int rando1to100%7) {
            call on triva game feature (new function)
        }
        else{
            call on menu
            if 1 -> battle
            if 2 -> change c points and end
        }
        }
        */
        }
        if (stoi(userInput) == 6) {
                cout << "Thank you" << user << " for playing!" << endl;
                cout << "Here are your stats: " endl;
                // display stats function, call on puppy class (shows us users stats)
                    //age, cuddle points, toys found
                    check = false;
        }
        else {
            cout << "Invalid Input Try Again" << endl;
        }
        
        cout << endl;
    }
    
}