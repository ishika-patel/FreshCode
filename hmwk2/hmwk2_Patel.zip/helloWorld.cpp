/* CS1300 Fall 2019
Author: Ishika Patel
Recitation: 104 - Anuj P
Homework 2 - Problem #1 */

#include <iostream>
using namespace std;

/* Algorithm: program prints Hello World 
Input parameters: none
Output: statment of Hello World!
Returns:none */

int main() {
    cout << "Hello, World!" << endl;
}

